<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f2ec0fd2abc5714608241a1a0eac321b'] = 'Block Kunden-Datenschutz';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_cb6b92b60c9302e74a26ac246d0af0fa'] = 'Fügt einen Block hinzu, um Informationen zum Kunden-Datenschutz anzuzeigen.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_d71315851e7e67cbacf5101c5c4ab83d'] = 'Ihre personenbezogenen Daten werden ausschließlich verwendet, um Ihre Anfragen zu beantworten, Ihre Aufträge zu bearbeiten oder Ihnen Zugang zu bestimmten Informationen zu verschaffen.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b43d08355db3df47796e65c72cfd5714'] = 'Sie können jederzeit Ihre persönlichen Angaben aktualisieren oder löschen - wählen Sie dazu bitte \"Mein Konto\".';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguration aktualisiert';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_d8b716e21c731aba4b94ba9f3ac4858c'] = 'Nachricht zu Kunden-Datenschutz';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Nachricht, die beim Anmeldevorgang angezeigt wird';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b51d73fb490ad1245fa9b87042bbbbb7'] = 'Tipp: Wenn der Text für das Feld zu lang geraten ist, können Sie einen Link hinzufügen, den Sie auf der \"CMS\"-Seite im Menü \"Voreinstellungen\" angelegt haben.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Bitte stimmen Sie den Datenschutzbedingungen zu, indem Sie auf das Kontrollkästchen unten klicken.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Kunden-Datenschutz';
