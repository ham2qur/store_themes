<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{referralprogram}prestashop>referralprogram_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{referralprogram}prestashop>referralprogram_386c339d37e737a436499d423a77df0c'] = 'Currency';
$_MODULE['<{referralprogram}prestashop>referralprogram_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{referralprogram}prestashop>referralprogram_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{referralprogram}prestashop>referralprogram_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{referralprogram}prestashop>referralprogram_22ffd0379431f3b615eb8292f6c31d12'] = 'Registration date';
$_MODULE['<{referralprogram}prestashop>program_d3d2e617335f08df83599665eef8a418'] = 'Close';
$_MODULE['<{referralprogram}prestashop>program_6540b502e953f4c05abeb8f234cd50bf'] = 'Referral program';
$_MODULE['<{referralprogram}prestashop>program_8d3f5eff9c40ee315d452392bed5309b'] = 'Last name';
$_MODULE['<{referralprogram}prestashop>program_20db0bfeecd8fe60533206a2b5e9891a'] = 'First name';
$_MODULE['<{referralprogram}prestashop>program_1e884e3078d9978e216a027ecd57fb34'] = 'E-mail';
$_MODULE['<{referralprogram}prestashop>program_31fde7b05ac8952dacf4af8a704074ec'] = 'Preview';
$_MODULE['<{referralprogram}prestashop>program_ad3d06d03d94223fa652babc913de686'] = 'Validate';
$_MODULE['<{referralprogram}prestashop>program_12c500ed0b7879105fb46af0f246be87'] = 'orders';
$_MODULE['<{referralprogram}prestashop>program_0b3db27bc15f682e92ff250ebb167d4b'] = 'Back to your account.';
$_MODULE['<{referralprogram}prestashop>program_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
