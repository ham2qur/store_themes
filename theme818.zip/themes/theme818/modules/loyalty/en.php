<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{loyalty}prestashop>loyalty_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{loyalty}prestashop>loyalty_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{loyalty}prestashop>loyalty_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{loyalty}prestashop>loyalty_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{loyalty}prestashop>loyalty_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{loyalty}prestashop>loyalty_38fb7d24e0d60a048f540ecb18e13376'] = 'Save';
$_MODULE['<{loyalty}prestashop>loyalty_44749712dbec183e983dcd78a7736c41'] = 'Date';
$_MODULE['<{loyalty}prestashop>loyalty_01abfc750a0c942167651c40d088531d'] = '#';
$_MODULE['<{loyalty}prestashop>loyalty_dd1f775e443ff3b9a89270713580a51b'] = 'Previous';
$_MODULE['<{loyalty}prestashop>loyalty_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Next';
$_MODULE['<{loyalty}prestashop>loyalty_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'All';
$_MODULE['<{loyalty}prestashop>loyalty_689202409e48743b914713f96d93947c'] = 'Value';
$_MODULE['<{loyalty}prestashop>loyalty_ca0dbad92a874b2f69b549293387925e'] = 'Code';
$_MODULE['<{loyalty}prestashop>loyalty_ec53a8c4f07baed5d8825072c89799be'] = 'Status';
$_MODULE['<{loyalty}prestashop>loyalty_3ec365dd533ddb7ef3d1c111186ce872'] = 'Details';
$_MODULE['<{loyalty}prestashop>loyalty_29aa46cc3d2677c7e0f216910df600ff'] = 'Free shipping';
$_MODULE['<{loyalty}prestashop>loyalty_019d1ca7d50cc54b995f60d456435e87'] = 'Used';
$_MODULE['<{loyalty}prestashop>loyalty_18fb6221fe0d9895c2e9ba08283f00e9'] = 'Order #%d';
$_MODULE['<{loyalty}prestashop>loyalty_0b3db27bc15f682e92ff250ebb167d4b'] = 'Back to your account.';
$_MODULE['<{loyalty}prestashop>loyalty_8cf04a9734132302f96da8e113e80ce5'] = 'Home';
