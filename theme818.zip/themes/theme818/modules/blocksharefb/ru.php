<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksharefb}prestashop>blocksharefb_cbe5bf6cf027e9f9e6cc0e8d725ebfa6'] = 'Блок Поделиться на Facebook';
$_MODULE['<{blocksharefb}prestashop>blocksharefb_f96f72b5ba39796e728cc55ddd1672cb'] = 'Добавляет блок \"Поделиться на Facebook\" на страницах товара.';
$_MODULE['<{blocksharefb}prestashop>blocksharefb_353005a70db1e1dac3aadedec7596bd7'] = 'Поделиться на Facebook';
