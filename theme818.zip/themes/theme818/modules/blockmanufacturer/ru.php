<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bc3e73cfa718a3237fb1d7e1da491395'] = 'Блок производителей';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_71087c7035e626bd33c72ae9a7f042af'] = 'Отображает блок производителей/брендов';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_067931ed6c365d76c9f32285a6b49839'] = 'Неверное количество элементов';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'Пожалуйста, активируйте хотя бы один системный список';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b4251faa73b3c8188623fdc8fe287513'] = 'Использовать текстовый список';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b9f5c797ebbf55adccdd8539a65a0241'] = 'Выключено';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Отображать';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_aa56a2e65d8106aef3c61e4f6bf94fdb'] = 'элемент(а)(ов)';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c6dfa38603c2ea64217d462000a09da4'] = 'Для отображения производителей в текстовом списке';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_ac88955a067710291274d21dec443904'] = 'Использовать выпадающий список';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_56353167778d1520bfecc70c470e6d8a'] = 'Для отображения производителей в выпадающем списке';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Производители';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_9d098ff02f6813055b869f6f9acd831c'] = 'Подробнее о';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'Все производители';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'Нет производителей';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_49fa2426b7903b3d4c89e2c1874d9346'] = 'Подробнее о';
