<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bc3e73cfa718a3237fb1d7e1da491395'] = 'Bloc fabricant';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_71087c7035e626bd33c72ae9a7f042af'] = 'Ajoute un bloc avec les fabricants/marques';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_067931ed6c365d76c9f32285a6b49839'] = 'Nombre non valable d\'éléments';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'Veuillez activer au moins un affichage de liste';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b4251faa73b3c8188623fdc8fe287513'] = 'Utiliser une liste en text brut';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Afficher';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_aa56a2e65d8106aef3c61e4f6bf94fdb'] = 'éléments';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c6dfa38603c2ea64217d462000a09da4'] = 'Affiche les fabricants sous forme de liste textuelle';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_ac88955a067710291274d21dec443904'] = 'Utiliser un menu déroulant';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_56353167778d1520bfecc70c470e6d8a'] = 'Affiche les fabricants sous forme de menu déroulant';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Fabricants';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_9d098ff02f6813055b869f6f9acd831c'] = 'En savoir plus sur';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'Tous les fabricants';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'Aucun fabricant';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_49fa2426b7903b3d4c89e2c1874d9346'] = 'En savoir plus sur';
