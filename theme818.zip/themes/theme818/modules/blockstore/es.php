<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockstore}prestashop>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'Bloque tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_2d7884c3777bd04028c4a55a820880a8'] = 'Mostrar un bloque con un link hacia la lista de tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_126b21ce46c39d12c24058791a236777'] = 'imagen no válida';
$_MODULE['<{blockstore}prestashop>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'se ha producido un error durante el envío';
$_MODULE['<{blockstore}prestashop>blockstore_efc226b17e0532afff43be870bff0de7'] = 'Parámetros actualizados';
$_MODULE['<{blockstore}prestashop>blockstore_151e79863510ec66281329505bf9fbde'] = 'Configuració del bloque tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_2dd1d28275cdb8b78ebd17f6e25aac0d'] = 'Imagen del bloque';
$_MODULE['<{blockstore}prestashop>blockstore_8c38cf08a0d0a01bd44c682479432350'] = 'Cambiar de imagen:';
$_MODULE['<{blockstore}prestashop>blockstore_3eedfc0fbc9042acf0ecfe0f325428c4'] = 'la imagen se mostrará en formato 174x115';
$_MODULE['<{blockstore}prestashop>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockstore}prestashop>blockstore_8c0caec5616160618b362bcd4427d97b'] = 'Nuestras tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_142fe29b7422147cdac10259a0333c11'] = 'Descubra nuestras tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'Nuestras tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'Descubra nuestras tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_28fe12f949fd191685071517628df9b3'] = 'Descubra nuestras tiendas';
