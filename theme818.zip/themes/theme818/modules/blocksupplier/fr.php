<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksupplier}prestashop>blocksupplier_9ae42413e3cb9596efe3857f75bad3df'] = 'Bloc fournisseurs';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_7518289633b3d69dfa42cfe8d64940a5'] = 'Ajoute un bloc affichant les fournisseurs.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_cf64d2d0bc5de5ce3d309d0e899d36fb'] = 'Nombre non valable d\'éléments';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'Veuillez activer au moins une liste.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_b4251faa73b3c8188623fdc8fe287513'] = 'Utiliser une liste textuelle';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Afficher';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_aa56a2e65d8106aef3c61e4f6bf94fdb'] = 'éléments';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_abafe33995bb3ad9f51fbbe2dd309bf8'] = 'Afficher les fournisseurs sous forme de liste';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_ac88955a067710291274d21dec443904'] = 'Utiliser un menu déroulant';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_d02aed94c0fd8800800f9ca6920acc4b'] = 'Afficher les fournisseurs avec un menu déroulant';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_1814d65a76028fdfbadab64a5a8076df'] = 'Fournisseurs';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_49fa2426b7903b3d4c89e2c1874d9346'] = 'En savoir plus sur';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_ecf253735ac0cba84a9d2eeff1f1b87c'] = 'Tous les fournisseurs';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_496689fbd342f80d30f1f266d060415a'] = 'Aucun fournisseur';
