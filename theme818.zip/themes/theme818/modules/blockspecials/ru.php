<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockspecials}prestashop>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Блок скидки';
$_MODULE['<{blockspecials}prestashop>blockspecials_42bcf407ca1621390ed7cbea2b2c0c62'] = 'Добавляет блок со скидками.';
$_MODULE['<{blockspecials}prestashop>blockspecials_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{blockspecials}prestashop>blockspecials_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockspecials}prestashop>blockspecials_41385d2dca40c2a2c7062ed7019a20be'] = 'Всегда отображать блок';
$_MODULE['<{blockspecials}prestashop>blockspecials_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{blockspecials}prestashop>blockspecials_b9f5c797ebbf55adccdd8539a65a0241'] = 'Запрещено';
$_MODULE['<{blockspecials}prestashop>blockspecials_a8a670d89a6d2f3fa59942fc591011ef'] = 'Отображать блок если нет товаров.';
$_MODULE['<{blockspecials}prestashop>blockspecials_805b7a76c72691ce8af0a5f458280237'] = 'Количество кэш-файлов';
$_MODULE['<{blockspecials}prestashop>blockspecials_3744927eb20f857847c982a14df23b69'] = 'Специальные файлы расположены во фронт-офисе произвольно, но так это требует большое количество ресурсов, то лучше кэшировать результаты. 0 отключит кэш.';
$_MODULE['<{blockspecials}prestashop>blockspecials_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{blockspecials}prestashop>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Скидки';
$_MODULE['<{blockspecials}prestashop>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Все скидки';
$_MODULE['<{blockspecials}prestashop>blockspecials_077a28bcf4e93718e678ec57128669a3'] = 'На данный момент специальных предложений нет';
$_MODULE['<{blockspecials}prestashop>blockspecials_fd21fcc9fc4c1d5202d6fc11597b3fca'] = 'Нет действующих скидок';
