<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_106a6c241b8797f52e1e77317b96a201'] = 'Accueil';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contact';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'plan du site';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_fad9383ed4698856ed467fd49ecf4820'] = 'favoris';
